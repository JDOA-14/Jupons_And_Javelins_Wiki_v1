# [[Kaelen Stormrage]] - Inventory
## Currency

- **Silver Pieces (sp):** 167
- **Gold Pieces (gp):** 400

---

## Weapons

- Quarterstaff (1d6 + Str or Dex)

---

## Armor & Shields

- 

---

## Potions & Elixirs

- 5 × Health Potions

---

## Magic Items

- Lantern of Wandering Spirit (reveals invisible creatures within 30 ft, 1 min/day)
- Moonlight Band (+1 Perception checks) (potentially sold)
- Ring of the Raider’s Focus _(uncommon)_ (Once per short rest: advantage on Perception checks or +1 Initiative) (potentially sold)
-  Robe (of protection) (+1 AC, +1 Saving Throw)

---

## Scrolls & Spell Items

- 

---

## Tools & Utensils

- Scholar’s Pack, containing:
    - Backpack
    - Bottle of Ink
    - Ink Pen
    - 10 Sheets of Parchment
    - Bag of Sand
    - Small Knife
    - 10 × Oil Flasks

---

## Letters, Notes & Maps

- 

---

## Food & Drink

- 7 × Rations
- 9 × Torches

---

## Treasures & Trinkets

- 

---

## Miscellaneous Gear

- 