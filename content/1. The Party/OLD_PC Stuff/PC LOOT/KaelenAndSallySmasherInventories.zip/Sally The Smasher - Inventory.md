# [[Sally the Smasher]] - Inventory

## Currency

- **Silver Pieces (sp):** 110
- **Gold Pieces (gp):** 235

---

## Weapons

- Great Axe (1d12 + Str)
- 3 × Hand Axe (1d6 + Dex)
- Maul +1 (2d6 + Str +1)
- Rusty Dagger

---

## Armor & Shields

- Chain Shirt (potentially sold)

---

## Potions & Elixirs

- 

---

## Magic Items

- Bracers of Vigor (Once per long rest, regain 1d4 HP when reduced to 0 HP)
- Pendant (+1 Intimidation checks AND Once Per Day gain advantage on a Performance check)
- Goblin’s Trick Coin (70% heads, 30% tails)

---

## Scrolls & Spell Items

- _(none in this loot dump)_
    

---

## Tools & Utensils

- Explorer’s Pack, containing:
    
    - Backpack
    - Bell
    - Bedroll
    - 2 Flasks of Oil
    - Rope
    - Tinderbox
    - 10 Torches
    - Waterskin

---

## Letters, Notes & Maps

- Drawing of a house map (potentially bandit house near Ashdawn)
- Used handkerchief
- Sealed wooden box (potentially sold)

---

## Food & Drink

- “10 days worth” of rations
- 8 × more rations

---

## Treasures & Trinkets

- Bone Dice

---

## Miscellaneous Gear

- 